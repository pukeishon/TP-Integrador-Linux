#!/bin/bash

# Script de backup - /opt/scripts/backup_full.sh

# Mostrar ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Validar argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: se requieren dos argumentos: origen y destino."
    echo "Use -help para más información."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# Verificar que existan origen y destino
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el directorio de origen no existe: $ORIGEN"
    exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el directorio de destino no existe: $DESTINO"
    exit 3
fi

# Obtener nombre base del origen para el nombre del archivo
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Realizar el backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Confirmación
echo "Backup realizado: $ARCHIVO"

